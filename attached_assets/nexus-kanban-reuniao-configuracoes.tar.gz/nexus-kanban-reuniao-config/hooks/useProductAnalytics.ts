export { useProductAnalytics } from '@/features/revendedora/hooks/useProductAnalytics';
