export { useChat } from '@/features/revendedora/hooks/useChat';
