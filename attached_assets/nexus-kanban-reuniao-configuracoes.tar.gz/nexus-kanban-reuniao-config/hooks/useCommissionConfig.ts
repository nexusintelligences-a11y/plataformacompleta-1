export { useCommissionConfig } from '@/features/revendedora/hooks/useCommissionConfig';
