export { useInventoryForecasting } from '@/features/revendedora/hooks/useInventoryForecasting';
