# Nexus Intelligence - Módulos Kanban, Reunião e Configurações

Este pacote contém somente os 3 módulos principais para reduzir créditos de importação:

## 📦 Conteúdo

- **kanban/** - Sistema de Kanban (Pipeline de Leads)
- **reuniao-platform/** - Plataforma de Reuniões (100ms Integration)
- **Configuracoes.tsx** - Página de Configurações
- **kanban-components/** - Componentes compartilhados do Kanban
- **hooks/** - Hooks reutilizáveis (useReuniao, use100ms, useBookings, etc)

## 🚀 Como Integrar com Outros Módulos

### 1. Copiar para seu projeto:
```bash
# Copie os diretórios para seu src/
cp -r kanban/ /seu-projeto/src/features/kanban
cp -r reuniao-platform/ /seu-projeto/src/features/reuniao-platform
cp -r kanban-components/ /seu-projeto/src/components/kanban
cp -r hooks/ /seu-projeto/src/hooks
cp Configuracoes.tsx /seu-projeto/src/pages/
```

### 2. Atualizar arquivo routes ou App.tsx:
Certifique-se de adicionar as rotas para estes módulos em seu arquivo de routing:

```typescript
// src/App.tsx ou src/routes.tsx
import KanbanPage from '@/features/kanban/pages/KanbanPage';
import ReuniaoDashboardPage from '@/features/reuniao-platform/pages/ReuniaoDashboardPage';
import Configuracoes from '@/pages/Configuracoes';

// Adicionar às rotas:
// <Route path="/kanban" element={<KanbanPage />} />
// <Route path="/reuniao" element={<ReuniaoDashboardPage />} />
// <Route path="/configuracoes" element={<Configuracoes />} />
```

### 3. Verificar Dependências:
O projeto usa as seguintes dependências principais (assumindo que já estão instaladas):
- React Router (wouter)
- React Query (@tanstack/react-query)
- React Hook Form + Zod
- Shadcn/ui components
- 100ms SDK (@100mslive/react-sdk)

### 4. Configuração Backend:
Certifique-se de que o backend suporta:
- POST /api/config/hms100ms - Salvar credenciais 100ms
- GET /api/config/hms100ms/credentials - Obter credenciais
- POST /api/config/hms100ms/test - Testar credenciais
- Endpoints de leads, reuniões e configurações

## ⚙️ Configurações Necessárias (100ms)

1. Visite https://dashboard.100ms.live
2. Vá para Settings → Credentials
3. Copie:
   - App Access Key
   - App Secret
   - Management Token (opcional)
   - Template ID (opcional)

4. Configure na página /configuracoes da sua aplicação

## 📝 Notas Importantes

- Este pacote foi otimizado para usar menos créditos de importação
- As dependências de banco de dados (Drizzle ORM schema) já devem estar configuradas
- Todos os componentes usam Shadcn/ui - certifique-se de que está disponível
- O sistema é multi-tenant - cada tenant tem suas próprias configurações

## 🔧 Estrutura de Pastas

```
kanban/
├── components/
│   ├── KanbanBoard.tsx
│   ├── LeadCard.tsx
│   └── ...
├── pages/
│   └── KanbanPage.tsx
├── hooks/
│   └── useKanban.ts
└── types/
    └── index.ts

reuniao-platform/
├── components/
│   ├── Meeting100ms.tsx
│   ├── ReuniaoCard.tsx
│   └── ...
├── pages/
│   ├── ReuniaoDashboardPage.tsx
│   └── ReuniaoHubPage.tsx
├── hooks/
│   └── useReuniao.ts
└── types/
    └── index.ts
```

## 💡 Support

Para integração completa, consulte a documentação original do projeto ou o developer.
